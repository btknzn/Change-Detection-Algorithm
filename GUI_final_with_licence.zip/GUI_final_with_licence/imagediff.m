
function[new,im2withchange_new] = imagediff(im1,im2,threshold)

% im1 = imread("w6.jpg");
% im2 = imread("w2.jpg");
% %[im1] = preprocessing(im1);
% %[im2] = preprocessing(im2);

[MOVINGREG] = registerImages(im1,im2);
%treshold image to detect black part
I = MOVINGREG.RegisteredImage >0,1;
% make it appropiate file format
I = uint8(I);
% apply filter used by treshold
im2moved = im2.*I;


%h1 = imhist(Img1);
%h2 = imhist(FIXED);
diff = (im2moved - MOVINGREG.RegisteredImage);
diff = rgb2gray(diff);
%threshold = 20;
new = diff >threshold;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%grayscale option
%imshow(new)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

im2withchange_new = im2;
im2withchange_new(:,:,2) = double(im2(:,:,2))+double(new*255);
%figure();
%imshow(im2withchange_new);
%figure();
%imshow(im2withchange_new);
%imshow([MOVINGREG.RegisteredImage,im2moved]);

end
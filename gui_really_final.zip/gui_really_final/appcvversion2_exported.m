classdef appcvversion2_exported < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                     matlab.ui.Figure
        TabGroup2                    matlab.ui.container.TabGroup
        Start                        matlab.ui.container.Tab
        importPanel                  matlab.ui.container.Panel
        ImportImagesLabel            matlab.ui.control.Label
        choiceDrop                   matlab.ui.control.DropDown
        detectChange                 matlab.ui.control.Label
        FilePathLabel                matlab.ui.control.Label
        TextArea_2                   matlab.ui.control.TextArea
        ImportButton                 matlab.ui.control.Button
        resultPanel                  matlab.ui.container.Panel
        ImageSlider                  matlab.ui.control.Slider
        ImageSliderLabel             matlab.ui.control.Label
        ThedetectedplaceisLabel      matlab.ui.control.Label
        TextArea                     matlab.ui.control.TextArea
        ExportButton                 matlab.ui.control.Button
        exportTypeSelector           matlab.ui.control.DropDown
        ExportresultasDropDownLabel  matlab.ui.control.Label
        Im                           matlab.ui.control.Image
        ResultsLabel                 matlab.ui.control.Label
        settingsPanel                matlab.ui.container.Panel
        DefaultparametersCheckBox    matlab.ui.control.CheckBox
        Slider                       matlab.ui.control.Slider
        modeSelector                 matlab.ui.control.DropDown
        ModeofchangeLabel            matlab.ui.control.Label
        Image2                       matlab.ui.control.Image
        ModeofvisualisationLabel     matlab.ui.control.Label
        visionSelector               matlab.ui.control.DropDown
        SelectAlgorithmLabel         matlab.ui.control.Label
        ButtonGroup                  matlab.ui.container.ButtonGroup
        imagdiff                     matlab.ui.control.RadioButton
        PCA                          matlab.ui.control.RadioButton
        ApplyButton                  matlab.ui.control.Button
        SettingsLabel                matlab.ui.control.Label
    end


    properties (Access = private)
        rate % Description
        block % Description
        paths
        images
        mapk
        sizeFile
        nameImage
    imageChanged
        algo
        toPlotImages
        grayImages
        threshold
    end


    % Callbacks that handle component events
    methods (Access = private)

        % Button pushed function: ImportButton
        function ImportButtonPushed(app, event)
            app.images ={};
            app.paths={};
            if(app.choiceDrop.Value=='1')
                [file,path] = uigetfile('*.jpg','Please choose 2 images','MultiSelect', 'on');
                app.sizeFile = size(file,2) ;
                if(app.sizeFile~=2)
                    f = errordlg('2 images must be choosen','File Error');
                    return
                else
                    path_2images = strrep(path,'\','/');
                    app.paths{1} = strcat(path_2images,file{1} );
                    app.paths{2} = strcat(path_2images,file{2} );
                    
                    app.TextArea_2.Value = path_2images;
                    app.nameImage = {file{1}, file{2}};
                    app.ImportImagesLabel.FontColor = [0.39,0.83,0.07];
                    app.ImportButton.BackgroundColor = [0.39,0.83,0.07];
                
                end
            elseif(app.choiceDrop.Value=='2')
                
                selectedData = uigetdir;
                if (selectedData == 0)
                    return
                end
                [pathstr, name, ext] = fileparts(selectedData);
                path_dataSet = strcat(pathstr,'\',name);
                path_dataSet = strrep(path_dataSet,'\','/');
                app.TextArea_2.Value = path_dataSet;

                folderDataset = path_dataSet;
                filePattern = fullfile(folderDataset, '*.jpg')
                theFiles = dir(filePattern);
                theFiles = struct2cell(theFiles);
                app.sizeFile = size(theFiles,2);

            app.ImportButton.BackgroundColor = [0.39,0.83,0.07];
            app.ImportImagesLabel.FontColor = [0.39,0.83,0.07];
                
             
                for i=1:app.sizeFile
                    app.paths{i} = strcat(path_dataSet ,'/',theFiles{1,i});
                    app.nameImage{i} = theFiles{1,i};
                end


            end
         

            for index = 1: numel(app.paths)
                app.images{index} = imread(app.paths{index});       
            end

            app.settingsPanel.Enable='on';
            app.resultPanel.Enable ='on';
            app.rate = 0.6;
            app.block = 2;
            
            
            if contains(app.paths{1},'Dubai')
                app.threshold = 20;
            elseif contains(app.paths{1},'Frauenkirche')
                app.threshold = 40;
            elseif contains(app.paths{1},'Wiesn')
                app.threshold = 40;
            elseif  contains(app.paths{1},'Glacier')
                app.threshold = 10;
            elseif  contains(app.paths{1},'Kuwait')
                app.threshold = 10;
            elseif  contains(app.paths{1},'Rainforest')
                app.threshold = 40;
            end
            
            
        end

        % Selection changed function: ButtonGroup
        function RadioButton_onClick(app, event)
            event = matlab.ui.eventdata.ValueChangedData(app.modeSelector.Value, app.modeSelector.Value)
            app.modeSelector.ValueChangedFcn(app, event)
            
        end

        % Button pushed function: ApplyButton
        function ApplyButtonPushed(app, event)
           
            % cleanup between runs 
            app.Im.ImageSource = '';
            app.imageChanged = {};
            app.grayImages = {};
            
            t=0;
            
            % customized analysis
            
            if(app.modeSelector.Value == '1')
                app.TextArea.Enable = 'on';
                app.ThedetectedplaceisLabel.Enable='on';
                if (contains(app.paths{1},'Dubai')|| contains(app.paths{1},'Frauenkirche')|| contains(app.paths{1},'Wiesen')  )
                    app.TextArea.Value = 'city';

                elseif (contains(app.paths{1},'Glacier')|| contains(app.paths{1},'Kuwait') )
                    app.TextArea.Value = 'Sea';

                elseif contains(app.paths{1},'Rainforest')
                    app.TextArea.Value = 'forest';
                end
            end
            
            if (app.DefaultparametersCheckBox.Value == 1)

                
                if(app.imagdiff.Value==1)

                    for i= 2:1:app.sizeFile
                        t=t+1;
                        if contains(app.paths{1},'Rainforest')
                            [ app.grayImages{t},app.imageChanged{t}] = imagediffwithpre(app.images{i},app.images{i-1},app.threshold);

                        else
                            [ app.grayImages{t},app.imageChanged{t}] = imagediff(app.images{i},app.images{i-1},app.threshold);
                        end
                    end
                elseif(app.PCA.Value==1)


                    for i=2:1:app.sizeFile
                        t=t+1;
                        [ app.grayImages{t},app.imageChanged{t}] = applyPCApre(app.images{i},app.images{i-1}, app.block,app.rate);
                    end
                end

            end

            if(app.modeSelector.Value == '1' || app.modeSelector.Value == '2')
                x=0;
                for i=2:1:app.sizeFile
                    x=x+1;
                    if (app.PCA.Value==1)
                        [ app.grayImages{x},app.imageChanged{x}] = applyPCApre(app.images{i},app.images{i-1},app.block,app.rate);
                    elseif(app.imagdiff.Value==1 && contains(app.paths{1},'Dubai')==1)
                        [ app.grayImages{x},app.imageChanged{x}] = imagediffDubai(app.images{i},app.images{i-1},app.Slider.Value);
                    elseif(app.imagdiff.Value==1 && contains(app.paths{1},'Dubai')==0)
                        [ app.grayImages{x},app.imageChanged{x}]= imagediff(app.images{i},app.images{i-1},app.Slider.Value);
                    end
                end
            elseif(app.modeSelector.Value=='3')

                if(app.sizeFile==2)
                    f = errordlg('This mode of change is only applicable on image-set','File Error');
                    return
                end
                
                value = round(app.Slider.Value);
                if(value == 1)
                    app.toPlotImages=[1:1:app.sizeFile];
                elseif(value == 2)
                    app.toPlotImages=[1,3 ,6, app.sizeFile];
                elseif(value == 3)
                    app.toPlotImages=[1, app.sizeFile];
                end

                indLimit = numel(app.toPlotImages) - 1;
                g=0;
                if(app.imagdiff.Value==1)
                    for i=1:indLimit
                        g=g+1;
                        index = app.toPlotImages(i);
                        if contains(app.paths{1},'Rainforest')
                            [ app.grayImages{g},app.imageChanged{g}] = imagediffwithpre(app.images{index+1},app.images{index},app.threshold);
                        else
                            [ app.grayImages{g},app.imageChanged{g}] = imagediff(app.images{index+1},app.images{index},app.threshold);
                        end
                    end
                elseif(app.PCA.Value==1)
                    for i=1:indLimit
                        g=g+1;
                        index = app.toPlotImages(i);
                        [ app.grayImages{g},app.imageChanged{g}] = applyPCApre(app.images{index+1},app.images{index}, app.block,app.rate);
                    end
                end
            elseif(app.modeSelector.Value == '4')
                y= 0;

                for i=2:1:app.sizeFile
                    y=y+1;
                    if (app.PCA.Value==1)
                        [ app.grayImages{y},app.imageChanged{y}] = applyPCApre(app.images{i},app.images{i-1},app.block,app.rate);
                    elseif(app.imagdiff.Value==1 && contains(app.paths{1},'Dubai')==1)
                        [ app.grayImages{y},app.imageChanged{y}] = imagediffDubaipre(app.images{i},app.images{i-1},app.Slider.Value);
                    elseif(app.imagdiff.Value==1 && contains(app.paths{1},'Dubai')==0)
                        [ app.grayImages{y},app.imageChanged{y}] = imagediffwithpre(app.images{i},app.images{i-1},app.Slider.Value);
                    end
                end
            end

            
            
            % Adjust Resultbox for selected

            if (app.visionSelector.Value== 1 )
                app.Im.ImageSource = app.imageChanged{1};
            elseif(app.visionSelector.Value == 2)
                
                ax = axes;
                imshow(app.grayImages{1},'Parent',ax);
                % not supported by matlab yet...
                %app.Im.ImageSource = app.grayImages{1};
                
            elseif(app.visionSelector.Value == 3)
                timeLapse(app.imageChanged);
                app.Im.ImageSource = app.imageChanged{1};
            end

            app.ApplyButton.BackgroundColor =[0.39,0.83,0.07];
            app.SettingsLabel.FontColor = [0.39,0.83,0.07];
            app.Image2.Visible = 'off';
            
            
            app.ImageSlider.MinorTicks=[];
            limit = size(app.imageChanged, 2);
            if limit > 1
                app.ImageSlider.Limits = [1 limit];
                app.ImageSlider.MajorTicks = [1:1:limit];
            
                for i= 1:numel(app.ImageSlider.MajorTicks)
                    app.ImageSlider.MajorTickLabels{1,i}= num2str( app.ImageSlider.MajorTicks(i)  )
                end
                app.ImageSliderLabel.Visible = 'on';
                app.ImageSlider.Visible = 'on'; 
            else                
                app.ImageSliderLabel.Visible = 'off';
                app.ImageSlider.Visible = 'off'; 
            end

        end

        % Drop down opening function: visionSelector
        function visionSelectorOpening(app, event)
         
         
            
        end

        % Value changed function: modeSelector
        function DropDown_onChange(app, event)
            app.rate = 0.6;
            app.block = 2;



            slider = app.Slider;

            if (app.modeSelector.Value =='2' && app.PCA.Value==1 )

                app.Slider.Enable='on';

                slider.Limits = [25 100];
                slider.MajorTicks = [25 50 75 100];
                slider.MajorTickLabels = {'25', '50', '75', '100'};
                slider.MinorTicks = [];

                if(slider.Value == 25)
                    app.rate =  0.9;
                    app.block = 8;
                elseif(slider.Value == 50 )
                    app.rate = 0.8;
                    app.block = 6;
                elseif(slider.Value==75)
                    app.rate = 0.7;
                    app.block = 4;

                elseif(slider.Value==100)
                    app.rate = 0.6;
                    app.block = 2;
                end

            elseif(app.modeSelector.Value=='2' && app.imagdiff.Value==1  )
                app.Slider.Enable='on';

                if( contains(app.paths{1},'Rainforest')==1 || contains(app.paths{1},'Glacier')==1 || contains(app.paths{1},'Wiesen')==1)

                    slider.Limits = [10 100];
                    slider.MajorTicks = [10 45 75 100];
                    slider.MajorTickLabels = {'10', '45', '75', '100'};
                    slider.MinorTicks = [];

                elseif (contains(app.paths{1},'Kuwait')==1 ||contains(app.paths{1},'Frauenkirche'))

                    slider.Limits = [30 100];
                    slider.MajorTicks = [30 60 75 100];
                    slider.MajorTickLabels = {'30', '60', '75', '100'};
                    slider.MinorTicks = [];

                elseif( contains(app.paths{1},'Dubai')==1   )
                    slider.Limits = [2 50];
                    slider.MajorTicks = [2 10 20  30 40 50];
                    slider.MajorTickLabels = {'2', '10', '20', '30','40','50'};
                    slider.MinorTicks = [];
                end

            end

            if (app.modeSelector.Value=='3'  &&( app.imagdiff.Value==1 || app.PCA.Value==1 ))
                % Update Slider state
                if(app.sizeFile==2)
                    f = errordlg('This mode of change is only applicable on image-set','File Error');
                else
                    app.Slider.Enable='on';
                    
                    slider.Limits = [1 3];
                    slider.MajorTicks = [1 2 3];
                    slider.MajorTickLabels = {'slow', 'normal', 'quick'};
                    slider.MinorTicks = []; 
                    
                end
            end
        
        end

        % Value changed function: DefaultparametersCheckBox
        function DefaultparametersCheckBoxValueChanged(app, event)
            app.rate = 0.9;
            app.block = 8;
            
            value = app.DefaultparametersCheckBox.Value;
            if(value==1)
                app.ModeofvisualisationLabel.Enable ='off';
                app.visionSelector.Enable='off';
                app.ModeofchangeLabel.Enable ='off';
                app.modeSelector.Enable = 'off';
                app.Slider.Enable='off';
                if contains(app.paths{1},'Dubai')
                    app.threshold = 20;
                elseif contains(app.paths{1},'Frauenkirche')
                    app.threshold = 40;
                elseif contains(app.paths{1},'Wiesn')
                    app.threshold = 40;
                elseif  contains(app.paths{1},'Glacier')
                    app.threshold = 10;
                elseif  contains(app.paths{1},'Kuwait')
                    app.threshold = 10;
                elseif  contains(app.paths{1},'Rainforest')
                    app.threshold = 40;
                end
            else

                app.ModeofvisualisationLabel.Enable ='on';
                app.visionSelector.Enable='on';
                app.ModeofchangeLabel.Enable ='on';
                app.modeSelector.Enable = 'on';
                app.Slider.Enable='on';
            end
        end

        % Image clicked function: Im
        function ImClicked(app, event)
            
            
            
            
            
            
            
        end

        % Value changed function: ImageSlider
        function ImageSliderValueChanged(app, event)
            value = round(app.ImageSlider.Value);
            
            if(app.visionSelector.Value==1||app.visionSelector.Value==3)
                app.Im.ImageSource = app.imageChanged{value};
            elseif(app.visionSelector.Value==2)
                ax = axes;
                imshow(app.grayImages{value},'Parent',ax);
                %app.Im.ImageSource = app.grayImages{value};
            end    
                
        end

        % Button pushed function: ExportButton
        function ExportButtonPushed(app, event)
            
            exportDir = uigetdir('', "Select folder for Export");
            type = app.exportTypeSelector.Value;
            
            images = 0;
            if (app.visionSelector.Value == 2)
                % grayscale
                images = app.grayImages;
            else
                images = app.imageChanged;
            end
            
            for i=1:size(images,2)
                name = strcat('export_image', num2str(i));
                path = strcat(exportDir, '\', name, '.', type);
                path = strrep(path,'/','\')
                imwrite(images{i}, path, type);
            end
            
            
            app.ResultsLabel.FontColor = [0.39,0.83,0.07];
            app.ExportButton.BackgroundColor = [0.39,0.83,0.07];
            app.Start.ForegroundColor = [0.39,0.83,0.07];
            
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [100 100 1077 828];
            app.UIFigure.Name = 'MATLAB App';

            % Create TabGroup2
            app.TabGroup2 = uitabgroup(app.UIFigure);
            app.TabGroup2.Position = [3 0 1077 829];

            % Create Start
            app.Start = uitab(app.TabGroup2);
            app.Start.Title = 'Computer Vision Challenge';
            app.Start.BackgroundColor = [0 0 0];
            app.Start.ForegroundColor = [1 0 0];

            % Create settingsPanel
            app.settingsPanel = uipanel(app.Start);
            app.settingsPanel.Enable = 'off';
            app.settingsPanel.ForegroundColor = [0.4706 0.6706 0.1882];
            app.settingsPanel.TitlePosition = 'centertop';
            app.settingsPanel.BackgroundColor = [0.251 0.251 0.251];
            app.settingsPanel.FontWeight = 'bold';
            app.settingsPanel.FontSize = 22;
            app.settingsPanel.Position = [24 28 481 500];

            % Create SettingsLabel
            app.SettingsLabel = uilabel(app.settingsPanel);
            app.SettingsLabel.FontSize = 22;
            app.SettingsLabel.FontWeight = 'bold';
            app.SettingsLabel.FontColor = [1 0 0];
            app.SettingsLabel.Position = [215 453 115 28];
            app.SettingsLabel.Text = 'Settings';

            % Create ApplyButton
            app.ApplyButton = uibutton(app.settingsPanel, 'push');
            app.ApplyButton.ButtonPushedFcn = createCallbackFcn(app, @ApplyButtonPushed, true);
            app.ApplyButton.BackgroundColor = [1 0 0];
            app.ApplyButton.FontSize = 16;
            app.ApplyButton.FontWeight = 'bold';
            app.ApplyButton.FontColor = [1 1 1];
            app.ApplyButton.Position = [133 21 200 33];
            app.ApplyButton.Text = 'Apply';

            % Create ButtonGroup
            app.ButtonGroup = uibuttongroup(app.settingsPanel);
            app.ButtonGroup.SelectionChangedFcn = createCallbackFcn(app, @RadioButton_onClick, true);
            app.ButtonGroup.ForegroundColor = [1 1 1];
            app.ButtonGroup.BorderType = 'none';
            app.ButtonGroup.BackgroundColor = [0.251 0.251 0.251];
            app.ButtonGroup.FontSize = 2;
            app.ButtonGroup.Position = [200 363 239 68];

            % Create PCA
            app.PCA = uiradiobutton(app.ButtonGroup);
            app.PCA.Text = 'PCA and k-means clustering';
            app.PCA.FontSize = 15;
            app.PCA.FontColor = [1 1 1];
            app.PCA.Position = [13 35 212 22];
            app.PCA.Value = true;

            % Create imagdiff
            app.imagdiff = uiradiobutton(app.ButtonGroup);
            app.imagdiff.Text = 'Image differencing';
            app.imagdiff.FontSize = 15;
            app.imagdiff.FontColor = [1 1 1];
            app.imagdiff.Position = [14 11 145 22];

            % Create SelectAlgorithmLabel
            app.SelectAlgorithmLabel = uilabel(app.settingsPanel);
            app.SelectAlgorithmLabel.FontSize = 20;
            app.SelectAlgorithmLabel.FontColor = [1 1 1];
            app.SelectAlgorithmLabel.Position = [10 396 179 24];
            app.SelectAlgorithmLabel.Text = '1) Select Algorithm:';

            % Create visionSelector
            app.visionSelector = uidropdown(app.settingsPanel);
            app.visionSelector.Items = {'difference-highlights', 'grayscale', 'Timelapse'};
            app.visionSelector.ItemsData = [1 2 3];
            app.visionSelector.DropDownOpeningFcn = createCallbackFcn(app, @visionSelectorOpening, true);
            app.visionSelector.Position = [247 201 209 22];
            app.visionSelector.Value = 1;

            % Create ModeofvisualisationLabel
            app.ModeofvisualisationLabel = uilabel(app.settingsPanel);
            app.ModeofvisualisationLabel.FontSize = 20;
            app.ModeofvisualisationLabel.FontColor = [1 1 1];
            app.ModeofvisualisationLabel.Position = [17 200 217 24];
            app.ModeofvisualisationLabel.Text = '3) Mode of visualisation';

            % Create Image2
            app.Image2 = uiimage(app.settingsPanel);
            app.Image2.Position = [152 446 48 42];
            app.Image2.ImageSource = 'icons8-settings-500.png';

            % Create ModeofchangeLabel
            app.ModeofchangeLabel = uilabel(app.settingsPanel);
            app.ModeofchangeLabel.FontSize = 20;
            app.ModeofchangeLabel.FontColor = [1 1 1];
            app.ModeofchangeLabel.Position = [16 239 172 24];
            app.ModeofchangeLabel.Text = {'2) Mode of change'; ''};

            % Create modeSelector
            app.modeSelector = uidropdown(app.settingsPanel);
            app.modeSelector.Items = {'city / countryside', 'large / little ', 'quick / slow', 'preproccessing'};
            app.modeSelector.ItemsData = {'1', '2', '3', '4'};
            app.modeSelector.ValueChangedFcn = createCallbackFcn(app, @DropDown_onChange, true);
            app.modeSelector.Position = [246 240 209 22];
            app.modeSelector.Value = '1';

            % Create Slider
            app.Slider = uislider(app.settingsPanel);
            app.Slider.Limits = [25 100];
            app.Slider.MajorTicks = [25 50 75 100];
            app.Slider.MajorTickLabels = {'25', '50', '75', '100'};
            app.Slider.MinorTicks = [];
            app.Slider.Enable = 'off';
            app.Slider.FontSize = 20;
            app.Slider.FontColor = [1 1 1];
            app.Slider.Position = [74 127 314 3];
            app.Slider.Value = 25;

            % Create DefaultparametersCheckBox
            app.DefaultparametersCheckBox = uicheckbox(app.settingsPanel);
            app.DefaultparametersCheckBox.ValueChangedFcn = createCallbackFcn(app, @DefaultparametersCheckBoxValueChanged, true);
            app.DefaultparametersCheckBox.Text = 'Default parameters';
            app.DefaultparametersCheckBox.FontSize = 20;
            app.DefaultparametersCheckBox.FontColor = [1 1 1];
            app.DefaultparametersCheckBox.Position = [17 279 193 23];

            % Create resultPanel
            app.resultPanel = uipanel(app.Start);
            app.resultPanel.Enable = 'off';
            app.resultPanel.BackgroundColor = [0.251 0.251 0.251];
            app.resultPanel.Position = [517 28 530 750];

            % Create ResultsLabel
            app.ResultsLabel = uilabel(app.resultPanel);
            app.ResultsLabel.HorizontalAlignment = 'center';
            app.ResultsLabel.FontSize = 22;
            app.ResultsLabel.FontWeight = 'bold';
            app.ResultsLabel.FontColor = [1 0 0];
            app.ResultsLabel.Position = [170 709 120 26];
            app.ResultsLabel.Text = 'Results';

            % Create Im
            app.Im = uiimage(app.resultPanel);
            app.Im.ImageClickedFcn = createCallbackFcn(app, @ImClicked, true);
            app.Im.Position = [24 301 494 332];

            % Create ExportresultasDropDownLabel
            app.ExportresultasDropDownLabel = uilabel(app.resultPanel);
            app.ExportresultasDropDownLabel.HorizontalAlignment = 'right';
            app.ExportresultasDropDownLabel.FontSize = 20;
            app.ExportresultasDropDownLabel.FontColor = [1 1 1];
            app.ExportresultasDropDownLabel.Position = [122 157 150 24];
            app.ExportresultasDropDownLabel.Text = 'Export result as:';

            % Create exportTypeSelector
            app.exportTypeSelector = uidropdown(app.resultPanel);
            app.exportTypeSelector.Items = {'jpg', 'png'};
            app.exportTypeSelector.Position = [309 158 100 22];
            app.exportTypeSelector.Value = 'jpg';

            % Create ExportButton
            app.ExportButton = uibutton(app.resultPanel, 'push');
            app.ExportButton.ButtonPushedFcn = createCallbackFcn(app, @ExportButtonPushed, true);
            app.ExportButton.BackgroundColor = [1 0 0];
            app.ExportButton.FontSize = 16;
            app.ExportButton.FontWeight = 'bold';
            app.ExportButton.FontColor = [1 1 1];
            app.ExportButton.Position = [150 21 200 33];
            app.ExportButton.Text = 'Export';

            % Create TextArea
            app.TextArea = uitextarea(app.resultPanel);
            app.TextArea.Editable = 'off';
            app.TextArea.HorizontalAlignment = 'center';
            app.TextArea.FontSize = 20;
            app.TextArea.FontWeight = 'bold';
            app.TextArea.FontColor = [1 1 1];
            app.TextArea.BackgroundColor = [0.251 0.251 0.251];
            app.TextArea.Enable = 'off';
            app.TextArea.Position = [247 645 168 28];

            % Create ThedetectedplaceisLabel
            app.ThedetectedplaceisLabel = uilabel(app.resultPanel);
            app.ThedetectedplaceisLabel.FontSize = 20;
            app.ThedetectedplaceisLabel.FontColor = [1 1 1];
            app.ThedetectedplaceisLabel.Enable = 'off';
            app.ThedetectedplaceisLabel.Position = [24 647 197 24];
            app.ThedetectedplaceisLabel.Text = 'The detected place is';

            % Create ImageSliderLabel
            app.ImageSliderLabel = uilabel(app.resultPanel);
            app.ImageSliderLabel.HorizontalAlignment = 'right';
            app.ImageSliderLabel.FontSize = 20;
            app.ImageSliderLabel.FontColor = [1 1 1];
            app.ImageSliderLabel.Position = [114 239 66 24];
            app.ImageSliderLabel.Text = 'Image ';

            % Create ImageSlider
            app.ImageSlider = uislider(app.resultPanel);
            app.ImageSlider.ValueChangedFcn = createCallbackFcn(app, @ImageSliderValueChanged, true);
            app.ImageSlider.FontSize = 20;
            app.ImageSlider.FontColor = [1 1 1];
            app.ImageSlider.Position = [201 250 196 3];

            % Create importPanel
            app.importPanel = uipanel(app.Start);
            app.importPanel.BackgroundColor = [0.251 0.251 0.251];
            app.importPanel.Position = [24 548 481 230];

            % Create ImportButton
            app.ImportButton = uibutton(app.importPanel, 'push');
            app.ImportButton.ButtonPushedFcn = createCallbackFcn(app, @ImportButtonPushed, true);
            app.ImportButton.Icon = 'icons8-browse-folder-90.png';
            app.ImportButton.BackgroundColor = [1 0 0];
            app.ImportButton.FontSize = 16;
            app.ImportButton.FontWeight = 'bold';
            app.ImportButton.FontColor = [1 1 1];
            app.ImportButton.Position = [132 11 200 27];
            app.ImportButton.Text = 'Import';

            % Create TextArea_2
            app.TextArea_2 = uitextarea(app.importPanel);
            app.TextArea_2.WordWrap = 'off';
            app.TextArea_2.FontColor = [1 1 1];
            app.TextArea_2.BackgroundColor = [0.251 0.251 0.251];
            app.TextArea_2.Position = [83 50 383 48];

            % Create FilePathLabel
            app.FilePathLabel = uilabel(app.importPanel);
            app.FilePathLabel.FontWeight = 'bold';
            app.FilePathLabel.FontColor = [1 1 1];
            app.FilePathLabel.Position = [18 63 56 22];
            app.FilePathLabel.Text = 'File Path';

            % Create detectChange
            app.detectChange = uilabel(app.importPanel);
            app.detectChange.FontSize = 20;
            app.detectChange.FontColor = [1 1 1];
            app.detectChange.Position = [11 125 162 24];
            app.detectChange.Text = {'Detect change on'; ''};

            % Create choiceDrop
            app.choiceDrop = uidropdown(app.importPanel);
            app.choiceDrop.Items = {'2 images', 'image-set'};
            app.choiceDrop.ItemsData = {'1', '2'};
            app.choiceDrop.Position = [186 124 211 26];
            app.choiceDrop.Value = '1';

            % Create ImportImagesLabel
            app.ImportImagesLabel = uilabel(app.importPanel);
            app.ImportImagesLabel.HorizontalAlignment = 'center';
            app.ImportImagesLabel.FontSize = 22;
            app.ImportImagesLabel.FontWeight = 'bold';
            app.ImportImagesLabel.FontColor = [1 0 0];
            app.ImportImagesLabel.Position = [140 189 156 27];
            app.ImportImagesLabel.Text = 'Import Images';

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = appcvversion2_exported

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end
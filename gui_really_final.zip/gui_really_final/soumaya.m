%RGB
% im2withchange_new(:,:,1)  red part of image
% im2withchange_new(:,:,2)  green part of image
% im2withchange_new(:,:,3)  blue part of image
% when we sum this 3 channel and show it is a colered image. 
% What we are doing is for example when we want to show change with red
% color. We are gibing the highest red value(255) for the changing parts
% pixels

i=1
im2withchange_new(:,:,i) = double(im2moved(:,:,i))+double(new*255);

%
i=2
im2withchange_new(:,:,i) = double(im2moved(:,:,i))+double(new*255);
%
i=3
im2withchange_new(:,:,i) = double(im2moved(:,:,i))+double(new*255);
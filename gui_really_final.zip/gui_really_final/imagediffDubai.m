
function[new, im2withchange_new] = imagediffDubai(im1,im2,threshold) 



%[im1] = preprocessing_blue(im1);
%[im2] = preprocessing_blue(im2);

%[im1] = preprocessing(im1);
%[im2] = preprocessing(im2);
%im1(im1(:,:,3)>200) = 0;
%im2(im2(:,:,3)>200) = 0;

[MOVINGREG] = registerImages(im1,im2);
%treshold image to detect black part 
I = MOVINGREG.RegisteredImage >0,1;
% make it appropiate file format
I = uint8(I);
% apply filter used by treshold 
im2moved = im2.*I;
im2moved = preprocessing_blue(im2moved);
imm = preprocessing_blue(MOVINGREG.RegisteredImage);
%h1 = imhist(Img1);
%h2 = imhist(FIXED);
diff = (im2moved - imm);
%diff = diff.*I;
diff = rgb2gray(diff);
%threshold = 2;
new = diff >threshold;
im2withchange_new = MOVINGREG.RegisteredImage;
im2withchange_new(:,:,2) = double(MOVINGREG.RegisteredImage(:,:,2))+double(new*255);
%t1 = toc;
%figure();
%imshow(im2withchange_new);
%figure();
%imshow(im2withchange_new);
%imshow([MOVINGREG.RegisteredImage,im2moved]);
end